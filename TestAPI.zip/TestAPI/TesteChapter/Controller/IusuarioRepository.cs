﻿namespace TesteChapter.Controller
{
    internal class IusuarioRepository
    {
    }
}